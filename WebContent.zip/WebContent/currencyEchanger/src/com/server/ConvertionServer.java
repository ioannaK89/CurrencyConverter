package com.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ConvertionServer
 */
@WebServlet("/ConvertionServer")
public class ConvertionServer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConvertionServer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String hidden = request.getParameter("requestName");		
		if(hidden.equals("InfoRequest")){
			response.sendRedirect("info.html");
		}
		else if(hidden.equals("CodeRequest")){
			response.sendRedirect("SourceCode.zip");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String amount = request.getParameter("Amount");   	//take the values who gave the user 
		String fromP = request.getParameter("From");
		String toP = request.getParameter("To");
		if(amount.equals("")){			//check if the input is empty
			out.write("Empty Input.");
			return;
		}
		double val;
		try{
			val = Double.valueOf(amount);
			if(val<0){				//check if the number is negative
				out.write("Negative Value Found");
				return;
			}
		}
		catch(Exception e){			//check if the input is different from number
			out.write("Invalid Input.Try double.");
			return;
		}
		URL url;
		String[] table = null;
		String[] from = fromP.split(" - ");		//split the input from because i need only the first part to send it to google and take the answer
		String[] to = toP.split(" - ");
		try {
	
			url = new URL("http://www.google.com/ig/calculator?hl=en&q="+amount+from[0]+"=?"+to[0]);
			BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));		//open stream to read the response
			String inputLine;
			inputLine = in.readLine();    //read the first linw from the response
			table = inputLine.split("\"");		//split the fields from the input line by the "
			in.close();
		
		} catch (IOException e) {
			e.printStackTrace();
		}
		out.write(table[1]+" = "+table[3]);
		out.flush();
	}

}
